#ifndef DISPLAY_h
#define DISPLAY_h

#include <Arduino.h>
void display_light(void);
void display_light0(void);
void display_light1(void);
void display_light2(void);
void display_light3(void);
void display_light4(void);

void led_breath(void);
void led_off(void);
void display_led(void);

#endif
